# Instala a Paco: lo agrega al inicio de Windows y lo abre ahora
$dir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ws = New-Object -ComObject WScript.Shell
$startup = [Environment]::GetFolderPath('Startup')
$s = $ws.CreateShortcut((Join-Path $startup 'Paco Flexit.lnk'))
$s.TargetPath = 'wscript.exe'
$s.Arguments = '"' + (Join-Path $dir 'paco.vbs') + '"'
$s.WorkingDirectory = $dir
$s.Save()
Start-Process wscript.exe ('"' + (Join-Path $dir 'paco.vbs') + '"')
Write-Host ''
Write-Host 'Listo: Paco aparece ahora abajo a la derecha, y de ahora en mas arranca solo con Windows.'
Write-Host 'Moverlo: arrastralo. Abrir Flexit: doble clic. Cerrarlo: clic derecho > Cerrar a Paco.'
