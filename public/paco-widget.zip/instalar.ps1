# Instala a Paco: lo agrega al inicio de Windows y lo abre ahora
$dir = Split-Path -Parent $MyInvocation.MyCommand.Path

# Chequeo: si falta algun archivo es porque se corrio desde adentro del ZIP (sin extraer)
$faltan = @('paco-widget.ps1','paco.vbs','paco-reposo.png','paco-levanta.png','paco-toma.png','com-mira.png','com-tipea.png','com-habla.png') |
  Where-Object { -not (Test-Path (Join-Path $dir $_)) }
if ($faltan) {
  Write-Host ''
  Write-Host '  X No encuentro los archivos de Paco al lado de este instalador.' -ForegroundColor Yellow
  Write-Host ''
  Write-Host '  Seguramente lo abriste desde ADENTRO del ZIP sin extraerlo.'
  Write-Host '  1. Cerra esta ventana'
  Write-Host '  2. Clic derecho en paco-widget.zip  >  "Extraer todo..."'
  Write-Host '  3. Entra a la carpeta extraida y hace doble clic en INSTALAR'
  Write-Host ''
  exit 1
}

$ws = New-Object -ComObject WScript.Shell
$startup = [Environment]::GetFolderPath('Startup')
$s = $ws.CreateShortcut((Join-Path $startup 'Paco Flexit.lnk'))
$s.TargetPath = 'wscript.exe'
$s.Arguments = '"' + (Join-Path $dir 'paco.vbs') + '"'
$s.WorkingDirectory = $dir
$s.Save()
Start-Process wscript.exe ('"' + (Join-Path $dir 'paco.vbs') + '"')
Write-Host ''
Write-Host 'Listo: Paco aparece ahora abajo a la derecha, y de ahora en mas arranca solo con Windows.'
Write-Host '(Si ya tenias a Paco abierto en esta compu, no se abre dos veces: queda el que ya estaba.)'
Write-Host 'Moverlo: arrastralo. Abrir Flexit: doble clic. Cerrarlo: clic derecho > Cerrar a Paco.'
